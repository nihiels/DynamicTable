/*
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
  */

var dsmxapi = {
  //translator
  trans: function(t,numbers,o){
    var out = t;
    //define translation object. Use funciton param o or global object "translations"
    var transO = o || translations || {};
    if (transO[t] !== undefined){
      out = transO[t];
    }
    //fill in numbers of the numbers function param
    if(numbers !== undefined){
      for(n in numbers){
        out = out.split("{"+n+"}").join(numbers[n]);
      }
    }
    return out;
  },
  //End translator
  //filter converter
  fStringer: function (f){
    f = f.replace(/\<\|/g,"[{").replace(/\|\>/g,"]}").replace(/\}/g,"]").replace(/\{/g,"[");
    return f;
  },
  //serialized Array to dsmx table
  formArrayToTable: function(a){
    //a = [{name:'x',value:'y'}];
    var out = {columns:[],rows:[]};
    var row = [];
    for(var c = 0; c < a.length; c++){
      out.columns.push(a[c].name);
      row.push(a[c].value);
    }
    out.rows.push(row);
    return out;
  },
  //End serialized Array to dsmx table
  //function to convert dsmx table back to serialized array
  fromTableToArray: function(table){
    //out = [{name:'x',value:'y'}];
    var out = [];
    var rows = table.rows;
    var columns = table.columns;
    for(var r = 0; r < rows.length; r++){
      var row = {};
      for(var c = 0; c < columns.length; c++){
        row[columns[c]] = rows[r][c];
      }
      out.push(row);
    }
    return out;
  },
  //End function to convert dsmx table back to serialized array
  //Create dsmxapi filter from array
  filterFromArray:function(a,operator,connector){
    // a = [['dbfield','value'],['dbfield2','value2']]; -> ((<|dbfield|> operator 'value') connector (<|dbfield2|> operator 'value2'))
     //((<|PL|> Equals 'BO') or (<|PL|> Equals 'MG'))
     var filterString = '';
     if(a.length === 1){
         filterString = "(<|"+a[0][0]+"|> "+operator+" '"+ a[0][1]+"')";
     }else{
       for(var i = 0; i < a.length; i++){
         if(i===0){
           filterString = "(<|"+a[i][0]+"|> "+operator+" '"+ a[i][1] +"') "+connector+" ";
         }else if(i+1<a.length){
           filterString = "(" + filterString;
           filterString += "(<|"+a[i][0]+"|> "+operator+" '"+ a[i][1] +"')) "+connector+" "
         }else if(i+1 === a.length){
           filterString = "(" + filterString;
           filterString += "(<|"+a[i][0]+"|> "+operator+" '"+ a[i][1] +"'))"
         }
       }

     }
     return filterString;
  },
  //End Create dsmxapi filter from array
  add:function(options){
    var defaults = {
      table:{
        "columns": [],
        "rows":[]
      },
      dr: "CampaignDatabase",
      callback: function(responseObject){
        console.log(responseObject);
        alert("Records created, responseOnject: " + responseObject);
      }
    };
    var settings = $.extend(defaults,options);
    var that = this;

    dsmx.api.dataRelations.create(settings.dr, settings.table, function(result){
      that.successCallback(result,function(responseObject){
        settings.callback(responseObject);
      });
    }, that.failCallback);
  },
  update:function(options){
    var defaults = {
      table:{
        "columns": [],
        "rows":[]
      },
      dr: "CampaignDatabase",
      callback: function(responseObject){
        console.log(responseObject);
        alert("Records updated, responseOnject: " + responseObject);
      }
    };
    var settings = $.extend(defaults,options);
    var that = this;

    dsmx.api.dataRelations.update(settings.dr, settings.table, function(result){
      that.successCallback(result,function(responseObject){
        settings.callback(responseObject);
      });
    }, that.failCallback);
  },
  get: function(options){
    var defaults = {
      query:{
        "mode" : "data",
        "filter": null,
        "columns": null
      },
      dr: "CampaignDatabase",
      callback: function(responseObject){
        alert("Records loaded: " + responseObject.rows.length);
      }
    };
    var settings = $.extend(defaults,options);
    var that = this;

    dsmx.api.dataRelations.get(settings.dr, settings.query, function(result){
      that.successCallback(result,function(responseObject){
        settings.callback(responseObject);
      });
    }, that.failCallback);

  },
  failCallback: function() {
      try{
        openDialog('Unable to update records');
      }catch(er){
        alert('Unable to update records');
      }
  },

  successCallback: function(result,cb) {
    if(result.state != 0) {
      try{
        openDialog('[' + result.failureDetail + '] ' + result.failureMessage);
      }catch(er){
        alert('[' + result.failureDetail + '] ' + result.failureMessage);
      }
    } else {
      if(cb!== undefined){
        cb(result.responseObject);
      }
    }
  }
}
